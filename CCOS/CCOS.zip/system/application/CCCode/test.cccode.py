import hash


print(hash.my_hash(1))
#include<windows.h>
#include<iostream>
int main(int argc,char *argv[])
{
	std::string s="";
	for(int i=1;i<argc;i++)	{s+=" ";s+=argv[i];}
	s=s.substr(16,s.length()-1);
	std::cout<<s;
	system(s.c_str());
} 

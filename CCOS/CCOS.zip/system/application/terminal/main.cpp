#include<windows.h>
int main()
{
	system("start cmd");
}
